# micro-motion

React parts with their micro-animations already right: rolling text and numbers,
buttons that change on themselves, heights that open with their content, popovers
that grow from their trigger, toasts, flights, a following highlight and more.

React 18+. No animation library. TypeScript types included.

## Install

Put the `.tgz` file in your project folder and run:

```bash
npm install ./micro-motion-1.0.0.tgz
```

## Use

Import the stylesheet once, at your app's root (`main.tsx`, `App.tsx`, or `app/layout.tsx` in Next.js):

```tsx
import 'micro-motion/styles.css'
```

Then use the parts anywhere:

```tsx
import { Button, Count, Collapse, Popover, Menu, Toast, Spinner } from 'micro-motion'

<Button variant="primary" icon={saving ? <Spinner /> : undefined}>
  {saving ? 'Saving' : 'Save'}
</Button>

<Count value={total} format={(n) => '€' + n.toLocaleString()} />
```

The components are marked `"use client"`, so they work in the Next.js App Router.

## Match your design

Override the tokens on `:root` in your own CSS (dark values under `[data-theme="dark"]` or `.dark`):

```css
:root {
  --ss-accent: #791ee5;
  --ss-text-strong: #111;
  --ss-radius-md: 10px;
}
```

All kit CSS sits in `@layer micro-motion`, so your own unlayered rules win without `!important`.
With Tailwind v4, put `@layer micro-motion, theme, base, components, utilities;` first in your main CSS.

## Docs

- `SKILL.md`: the full method (timing table, rules, bug checklist) and every part's props, with recipes.
  It refers to the source as `kit/`, which is included in this package.
- `kit/`: the TypeScript source, if you prefer to copy the files into a project instead of installing.

Parts: `Roll`, `Count`, `Swap`, `States`, `Stream`, `Collapse`, `Popover`, `Menu`, `Fly`, `Follow`,
`Expand`, `Button`, `Toggle`, `Segmented`, `Tabs`, `Badge`, `Slot`, `Chip`, `Toast`, `Tooltip`,
`Spinner`, `Check`, `Meter`. Helpers: `EASE`, `easeCss`, `bezier`, `rectIn`, `useReducedMotion`, `StillContext`.

Adapted from Stageshow by Benji Taylor (MIT).
