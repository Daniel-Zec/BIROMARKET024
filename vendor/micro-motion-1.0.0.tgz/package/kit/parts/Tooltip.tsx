import type { CSSProperties, ReactNode, HTMLAttributes } from 'react'
import type { Rect } from '../measure'
import './Tooltip.css'

/**
 * A small dark label naming the control under the pointer: centered on the
 * target's rect (from `rectIn()`), just below it or above it. It comes in fast
 * a few px (`gap`) from the target's side, as interface feedback does, and leaves
 * faster. Show it once the pointer has rested on the target (about 500ms) and hide
 * it on the click. A tooltip names an icon; it never carries the story.
 */
export function Tooltip({ show, at, side = 'below', gap = 6, children, className, style, ...rest }: { show: boolean; at: Rect; side?: 'below' | 'above'; gap?: number; children: ReactNode; className?: string; style?: CSSProperties } & Omit<HTMLAttributes<HTMLElement>, 'children'>) {
  const x = at.x + at.width / 2
  const y = side === 'below' ? at.y + at.height + gap : at.y - gap
  return (
    <span {...rest} className={`ss-tooltip${className ? ` ${className}` : ''}`} data-show={(show && at.width > 0) || undefined} data-side={side} style={{ left: x, top: y, ...style }} role="tooltip">
      <span className="ss-tooltip__label">{children}</span>
    </span>
  )
}
