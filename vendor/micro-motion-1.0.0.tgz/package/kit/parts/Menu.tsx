import type { CSSProperties, ReactNode, HTMLAttributes } from 'react'
import './Menu.css'

/**
 * A menu's rows, for a Popover. The row under the pointer highlights at once
 * and eases out when the pointer leaves, as a native menu does. `value` keeps
 * a row highlighted from outside (keyboard navigation you drive).
 *
 *   <Popover show={open} origin="top left"><Menu items={['Rename', 'Duplicate', 'Delete']} onSelect={run} /></Popover>
 */
export function Menu({ items, value, onSelect, className, style, ...rest }: {
  items: ReactNode[]
  /** A row held highlighted (the keyboard's position). */
  value?: number
  onSelect?: (index: number) => void
  className?: string
  style?: CSSProperties
} & Omit<HTMLAttributes<HTMLElement>, 'onSelect' | 'children'>) {
  return (
    <div {...rest} className={`ss-menu${className ? ` ${className}` : ''}`} style={style} role="menu">
      {items.map((item, i) => (
        <button key={i} type="button" className="ss-menu__item" data-active={i === value || undefined} role="menuitem" onClick={() => onSelect?.(i)}>
          {item}
        </button>
      ))}
    </div>
  )
}
