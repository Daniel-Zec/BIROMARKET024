import type { CSSProperties, ReactNode, HTMLAttributes } from 'react'
import './Toast.css'

/**
 * A confirmation that rises in from the bottom of whatever it sits in: "Link
 * copied", "Snoozed until 8:00 AM". Dark pill on light themes, raised surface
 * on dark. Position its container where your app shows toasts; it stays in
 * the DOM and fades, so it never pops. `--ss-toast-rise` sets how far it rises.
 *
 *   <Toast show={copied} icon={<CheckIcon />}>Link copied</Toast>
 */
export function Toast({ show, icon, children, action, className, style, ...rest }: { show: boolean; icon?: ReactNode; children: ReactNode; action?: ReactNode; className?: string; style?: CSSProperties } & Omit<HTMLAttributes<HTMLElement>, 'children'>) {
  return (
    <div {...rest} className={`ss-toast${className ? ` ${className}` : ''}`} data-show={show || undefined} style={style} role="status" aria-live="polite">
      {icon && <span className="ss-toast__icon" aria-hidden>{icon}</span>}
      <span>{children}</span>
      {action && <span className="ss-toast__action">{action}</span>}
    </div>
  )
}
