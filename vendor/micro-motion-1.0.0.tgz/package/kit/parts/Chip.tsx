import { useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode, type HTMLAttributes } from 'react'
import './Chip.css'

/**
 * A filter chip with an optional remove x. It arrives by opening its own
 * width (the chips after it slide over rather than jump) and leaves the same
 * way: keep it mounted with `show={false}` until its width has closed, then
 * drop it from your list (onTransitionEnd, or a timeout of about 500ms).
 *
 *   <Chip show={!removing} gap={6} onRemove={() => setRemoving(true)}>Status: Open</Chip>
 */
export function Chip({ show = true, onRemove, removeLabel = 'Remove', gap = 0, children, className, style, ...rest }: {
  show?: boolean
  /** Shows the x; called when it is pressed. */
  onRemove?: () => void
  /** The x's accessible name. */
  removeLabel?: string
  /** The row's own gap, so a removed chip takes no space at all. */
  gap?: number
  children: ReactNode
  className?: string
  style?: CSSProperties
} & Omit<HTMLAttributes<HTMLElement>, 'children'>) {
  // Measured, so the slot opens to exactly the chip's width wherever it sits (a flex row would shrink a CSS-only version)
  const chip = useRef<HTMLSpanElement>(null)
  const [w, setW] = useState<number | null>(null)
  useLayoutEffect(() => {
    if (chip.current) setW(chip.current.offsetWidth)
  }, [children])
  return (
    <span {...rest} className={`ss-chip-slot${className ? ` ${className}` : ''}`} data-show={show || undefined} style={{ width: show ? (w ?? 'auto') : 0, marginRight: show ? 0 : -gap, ...style }}>
      <span ref={chip} className="ss-chip" data-removable={onRemove ? '' : undefined}>
        <span className="ss-chip__label">{children}</span>
        {onRemove && (
          <button type="button" className="ss-chip__x" aria-label={removeLabel} tabIndex={show ? 0 : -1} onClick={onRemove}>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" aria-hidden>
              <path d="M2.5 2.5l5 5M7.5 2.5l-5 5" />
            </svg>
          </button>
        )}
      </span>
    </span>
  )
}
