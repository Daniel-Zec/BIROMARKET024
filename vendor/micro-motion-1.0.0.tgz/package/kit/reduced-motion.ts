import { createContext, useContext, useEffect, useState } from 'react'

// Wrap a subtree in <StillContext.Provider value> to settle its parts (a
// screenshot, a visual test) even without an OS preference.
export const StillContext = createContext(false)

/** Whether the viewer asked for reduced motion. Parts skip their tweens and land at once. */
export function useReducedMotion() {
  const still = useContext(StillContext)
  const [reduced, setReduced] = useState(false)
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    const update = () => setReduced(mq.matches)
    update()
    mq.addEventListener('change', update)
    return () => mq.removeEventListener('change', update)
  }, [])
  return still || reduced
}
