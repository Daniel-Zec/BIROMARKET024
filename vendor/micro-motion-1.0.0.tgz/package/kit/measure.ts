// Measuring: rects for the parts that place themselves from a measured box
// (Fly, Follow, Expand, Tooltip). Every rect is in the layout pixels of a
// container you choose: the positioned element the overlay sits in.

export type Point = { x: number; y: number }
export type Rect = { x: number; y: number; width: number; height: number }

export const EMPTY: Rect = { x: 0, y: 0, width: 0, height: 0 }

/**
 * Where `el` sits inside `container`, in the container's own layout pixels,
 * measured from the inside of its border (where its absolutely positioned
 * children are placed). Scroll offset and any scale on the container (a
 * zoomed panel) are accounted for. Give the container `position: relative`
 * and render the Fly, Follow or Tooltip inside it.
 *
 *   const r = rectIn(listRef.current, rowRef.current)
 */
export function rectIn(container: HTMLElement, el: HTMLElement): Rect {
  const c = container.getBoundingClientRect()
  const b = el.getBoundingClientRect()
  const scale = (container.offsetWidth && c.width / container.offsetWidth) || 1
  return {
    x: (b.left - c.left) / scale - container.clientLeft + container.scrollLeft,
    y: (b.top - c.top) / scale - container.clientTop + container.scrollTop,
    width: b.width / scale,
    height: b.height / scale,
  }
}

/** Rect helpers for positioning overlays from measured targets. */
export const inset = (r: Rect, by: number): Rect => ({ x: r.x - by, y: r.y - by, width: r.width + by * 2, height: r.height + by * 2 })
export const box = (r: Rect) => ({ left: r.x, top: r.y, width: r.width, height: r.height })
export const between = (a: Point, b: Point): Rect => ({
  x: Math.min(a.x, b.x),
  y: Math.min(a.y, b.y),
  width: Math.abs(b.x - a.x),
  height: Math.abs(b.y - a.y),
})
export const contains = (outer: Rect, inner: Rect) =>
  inner.x >= outer.x && inner.y >= outer.y && inner.x + inner.width <= outer.x + outer.width && inner.y + inner.height <= outer.y + outer.height
