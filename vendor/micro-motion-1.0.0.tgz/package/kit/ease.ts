// Named curves, as numbers (for motion you drive by hand) and as CSS. These
// are the curves the kit's own parts use; the table in SKILL.md (Timing) says
// which job each one is for and how long it runs.

export type Bezier = readonly [number, number, number, number]

export const EASE = {
  /** Controls settling: a knob, a thumb, an underline, a label's width. Fast start, long soft stop. 200 to 350ms. */
  out: [0.22, 1, 0.36, 1],
  /** The press: a button scaling to 0.97 under the pointer. 80 to 180ms. */
  press: [0.2, 0.8, 0.2, 1],
  /** Travel between two stable positions: a departure, clear travel, a soft arrival. 400 to 700ms. */
  travel: [0.45, 0, 0.1, 1],
  /** A height opening or closing (Collapse): an even start and a soft landing. 420 to 500ms. */
  height: [0.4, 0, 0.2, 1],
  /** Something arriving from nowhere, or a slot opening its width (Chip). 400ms in UI, up to 1s in storytelling. */
  arrive: [0.25, 0.8, 0.25, 1],
  /** In-app responses on a phone, UIKit-quick: a card opening, a sheet. About 500ms. */
  native: [0.3, 0.75, 0.1, 1],
  /** A swipe thrown at the finger's speed: a page or a row leaving. About 500ms. */
  throw: [0.25, 1, 0.5, 1],
  /** A surface sliding in from an edge (a drawer, a sheet). About 420ms. */
  sheet: [0.32, 0.72, 0, 1],
  /** Leaving: accelerates away, for something dismissed off screen. 200 to 250ms. */
  exit: [0.4, 0, 1, 1],
} as const satisfies Record<string, Bezier>

export type EaseName = keyof typeof EASE

export const css = (e: EaseName | Bezier) => {
  const [a, b, c, d] = typeof e === 'string' ? EASE[e] : e
  return `cubic-bezier(${a}, ${b}, ${c}, ${d})`
}

/** cubic-bezier(x1, y1, x2, y2) as a function of time 0..1, as CSS works it out. */
export function bezier(e: EaseName | Bezier): (t: number) => number {
  const [x1, y1, x2, y2] = typeof e === 'string' ? EASE[e] : e
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by
  const x = (u: number) => ((ax * u + bx) * u + cx) * u
  const dx = (u: number) => (3 * ax * u + 2 * bx) * u + cx
  return (t: number) => {
    if (t <= 0) return 0
    if (t >= 1) return 1
    // Newton, falling back to bisection where the slope is flat
    let u = t
    for (let i = 0; i < 8; i++) {
      const d = dx(u)
      if (Math.abs(d) < 1e-6) break
      const next = u - (x(u) - t) / d
      if (next < 0 || next > 1) break
      u = next
    }
    if (Math.abs(x(u) - t) > 1e-6) {
      let lo = 0, hi = 1
      for (let i = 0; i < 40; i++) {
        u = (lo + hi) / 2
        if (x(u) < t) lo = u
        else hi = u
      }
    }
    return ((ay * u + by) * u + cy) * u
  }
}
