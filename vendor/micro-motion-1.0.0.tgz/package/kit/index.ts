// micro-motion kit: React parts whose motion is already right.
// Copy this folder into your project (e.g. src/kit) and import from it.
// Needs React 18+. No animation library. Each part imports its own CSS;
// the tokens below are imported once here.
import './tokens.css'

// Motion: text, numbers, heights, surfaces and objects that change
export { Roll } from './motion/Roll'
export { Count } from './motion/Count'
export type { CountProps } from './motion/Count'
export { Swap } from './motion/Swap'
export { States } from './motion/States'
export { Collapse } from './motion/Collapse'
export { Popover } from './motion/Popover'
export type { PopoverOrigin } from './motion/Popover'
export { Follow, cellOf } from './motion/Follow'
export type { FollowProps } from './motion/Follow'
export { Fly } from './motion/Fly'
export type { FlyProps } from './motion/Fly'
export { Stream } from './motion/Stream'
export { Expand } from './motion/Expand'

// Controls with their motion built in
export { Button } from './controls/Button'
export type { ButtonProps } from './controls/Button'
export { Toggle } from './controls/Toggle'
export { Segmented } from './controls/Segmented'
export { Tabs } from './controls/Tabs'
export { Badge } from './controls/Badge'
export { Slot } from './controls/Slot'

// Small parts
export { Toast } from './parts/Toast'
export { Spinner } from './parts/Spinner'
export { Check } from './parts/Check'
export { Chip } from './parts/Chip'
export { Menu } from './parts/Menu'
export { Tooltip } from './parts/Tooltip'
export { Meter } from './parts/Meter'

// Timing, measuring, reduced motion
export { EASE, bezier, css as easeCss } from './ease'
export type { EaseName, Bezier } from './ease'
export { rectIn, inset, box, between, contains, EMPTY } from './measure'
export type { Point, Rect } from './measure'
export { useReducedMotion, StillContext } from './reduced-motion'
