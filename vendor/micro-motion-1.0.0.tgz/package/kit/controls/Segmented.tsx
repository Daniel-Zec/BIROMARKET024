import type { CSSProperties, ReactNode, HTMLAttributes } from 'react'
import './Segmented.css'

/**
 * A segmented control: equal segments, one raised thumb that slides to the
 * chosen one. The thumb moves; the labels only change color. Arrow keys move
 * the choice, as a radio group does.
 *
 *   <Segmented items={['Day', 'Week', 'Month']} value={view} onChange={setView} aria-label="View" />
 */
export function Segmented({ items, value, onChange, className, style, ...rest }: {
  items: ReactNode[]
  /** The selected index. */
  value: number
  onChange?: (index: number) => void
  className?: string
  style?: CSSProperties
  'aria-label'?: string
} & Omit<HTMLAttributes<HTMLElement>, 'onChange' | 'children'>) {
  const move = (to: number) => onChange?.((to + items.length) % items.length)
  return (
    <div {...rest} role="radiogroup" className={`ss-seg${className ? ` ${className}` : ''}`} style={{ ['--n' as string]: items.length, ...style }}>
      <span className="ss-seg__thumb" aria-hidden style={{ transform: `translateX(${value * 100}%)` }} />
      {items.map((o, i) => (
        <button
          key={i}
          type="button"
          role="radio"
          aria-checked={i === value}
          tabIndex={i === value ? 0 : -1}
          className="ss-seg__option"
          data-on={i === value || undefined}
          onClick={() => onChange?.(i)}
          onKeyDown={(e) => {
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); move(value + 1) }
            if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); move(value - 1) }
          }}
        >
          {o}
        </button>
      ))}
    </div>
  )
}
