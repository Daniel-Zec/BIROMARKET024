import type { ButtonHTMLAttributes } from 'react'
import './Toggle.css'

/**
 * A switch. The knob slides on the out curve and the track takes the accent
 * when on. A real button with role="switch": give it an aria-label (or a
 * visible <label>) and flip `on` in onChange.
 *
 *   <Toggle on={wifi} onChange={setWifi} aria-label="Wi-Fi" />
 */
export function Toggle({ on, onChange, className, onClick, type = 'button', ...rest }: Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onChange'> & { on: boolean; onChange?: (on: boolean) => void }) {
  return (
    <button
      type={type}
      role="switch"
      aria-checked={on}
      {...rest}
      className={`ss-toggle${className ? ` ${className}` : ''}`}
      data-on={on || undefined}
      onClick={(e) => {
        onClick?.(e)
        if (!e.defaultPrevented) onChange?.(!on)
      }}
    >
      <span className="ss-toggle__knob" />
    </button>
  )
}
