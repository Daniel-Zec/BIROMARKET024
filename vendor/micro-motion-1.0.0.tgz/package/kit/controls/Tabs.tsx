import { useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode, type HTMLAttributes } from 'react'
import './Tabs.css'

/**
 * A row of tabs with an underline that slides to the active one, measured, so
 * tabs can be any width. The underline is a 1px line scaled to the tab's
 * width, so it moves on transform alone. It re-measures when the row resizes
 * (a font loading, a label changing), so it never sits under the wrong width.
 *
 *   <Tabs items={['Overview', 'Activity', 'Settings']} value={tab} onChange={setTab} />
 */
export function Tabs({ items, value, onChange, className, style, ...rest }: {
  items: ReactNode[]
  /** The active index. */
  value: number
  onChange?: (index: number) => void
  className?: string
  style?: CSSProperties
  'aria-label'?: string
} & Omit<HTMLAttributes<HTMLElement>, 'onChange' | 'children'>) {
  const row = useRef<HTMLDivElement>(null)
  const [bar, setBar] = useState({ x: 0, w: 0 })
  useLayoutEffect(() => {
    const measure = () => {
      // children[0] is the bar; the tabs follow it
      const el = row.current?.children[value + 1] as HTMLElement | undefined
      if (el) setBar((b) => (b.x === el.offsetLeft && b.w === el.offsetWidth ? b : { x: el.offsetLeft, w: el.offsetWidth }))
    }
    measure()
    if (!row.current || typeof ResizeObserver === 'undefined') return
    const ro = new ResizeObserver(measure)
    ro.observe(row.current)
    for (const child of Array.from(row.current.children)) ro.observe(child)
    return () => ro.disconnect()
  }, [value, items.length])
  const move = (to: number) => onChange?.((to + items.length) % items.length)
  return (
    <div {...rest} ref={row} role="tablist" className={`ss-tabs${className ? ` ${className}` : ''}`} style={style}>
      <span className="ss-tabs__bar" aria-hidden style={{ transform: `translateX(${bar.x}px) scaleX(${bar.w})` }} />
      {items.map((t, i) => (
        <button
          key={i}
          type="button"
          role="tab"
          aria-selected={i === value}
          tabIndex={i === value ? 0 : -1}
          className="ss-tabs__tab"
          data-on={i === value || undefined}
          onClick={() => onChange?.(i)}
          onKeyDown={(e) => {
            if (e.key === 'ArrowRight') { e.preventDefault(); move(value + 1) }
            if (e.key === 'ArrowLeft') { e.preventDefault(); move(value - 1) }
          }}
        >
          {t}
        </button>
      ))}
    </div>
  )
}
