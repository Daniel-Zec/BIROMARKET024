---
name: micro-motion
description: Micro-animations and micro-interactions for real app UI. Use whenever building or polishing an interface that changes state - a button whose label or icon changes, numbers or statuses that update, rows added to or removed from a list, menus and popovers, toasts, toggles, tabs, segmented controls, filter chips, loading to content, drag and reorder, a card opening into a detail view - or when asked to make a UI feel polished, smooth or alive, even if nobody says "animation". Timing and easing rules, a bug checklist, and a small React kit with the motion already right.
---

# Micro-motion

The small motions that make an interface feel made with care: a button that changes its own words, a total that rolls to its new value, a row that opens its space so the list below moves with it, a menu that grows from the button that opened it. This file is the whole method. `kit/` beside it holds React parts with the motion already right; the rules stand on their own for any other stack.

Adapted from Stageshow by Benji Taylor (MIT, see `LICENSE`), keeping only what applies to real interfaces.

## The one idea

**Every motion has a cause, nothing pops, only what changed moves, and feedback is as fast as the input.**

Five ways it fails:

- **It pops.** Something appears or vanishes in one frame: a toast, a menu, an icon, a row. Everything has an entrance and stays mounted until its exit has finished.
- **It shoves.** Something new arrives and its neighbors jump to make room, or a label grows and the button beside it snaps over at the end. The space moves with the thing.
- **It swaps.** The old element is replaced by a new one (a second button for "Saved", a check icon that replaces a plus) instead of the same element changing. Identity is lost and the eye has to re-find it.
- **It lags.** The press waits for an animation, or a result appears before the press has registered. Feedback starts on the input; only the consequence may take time.
- **It performs.** Everything moves at once, everything bounces, things pulse after they've settled, motion runs long because it looks nice. Motion serves the change; when a still would read as well, stop.

## How to work

1. **Name the change before choosing any timing.** What holds still (the frame), what starts it (the input), what depends on it (a total, a label, a list), where it ends, and what holds afterwards. A quiet frame gives the moving parts something to move against.
2. **Pick the pattern** from the sections below. Most changes are one of: text or a number changing, something appearing or leaving, a surface opening, a choice moving, an object traveling.
3. **Use the kit part, never a lookalike.** Before hand-writing a button, switch, tabs, menu, toast, chip or counter, check `kit/`. A hand-built one is where uneven padding, squeezed labels, label jumps and popping icons come from. Restyle a part with its tokens and a class; don't reshape its geometry from outside.
4. **Time it by job** (the Timing table), not with one duration everywhere.
5. **Check the frames between,** not the end states: interrupt it, reverse it, turn on reduced motion (How to check).

## Timing and easing

UI motion runs at product speed. Only storytelling (onboarding, empty states, a marketing demo) slows down.

| Job | Duration | Curve | Notes |
|---|---|---|---|
| Press | 80ms in, about 180ms out | `press` (0.2, 0.8, 0.2, 1) | Scale to 0.97 on pointer-down. Starts on the input, never delayed. |
| Hover | Instant to 120ms in, 150ms out | `ease` | Fast in, eased out. One step of the element's own color, never a gray swap. |
| Selected state (a tool, a row, a filter) | About 150ms each way | `ease` | Fades in; never switches on in one frame. |
| Control settling (switch knob, segmented thumb, tab underline) | 220 to 350ms | `out` (0.22, 1, 0.36, 1) | Fast start, long soft stop. |
| A label or value changing width | 220 to 500ms | `out` | The width eases so neighbors move with it. |
| Color between distant hues | About 200ms | `ease` | It passes through mud however it's done, so keep it short; let the label carry the slower motion. |
| Height opening or closing | 420 to 500ms | `height` (0.4, 0, 0.2, 1) | Content fades in as the edge passes it; on close it dims first. |
| Popover or menu | 180ms fade in, 240ms scale from 0.96; 240ms out | `out` in, `exit` (0.4, 0, 1, 1) out | Scales from the side nearest its trigger; the text only fades. |
| Toast | 350ms fade, 600ms rise of about 10px | `out` | It rises in and fades out; it never pops. |
| Number rolling | About 700ms, 45ms between digits | `native` (0.3, 0.75, 0.1, 1) | Last digit first, unchanged digits still. |
| Travel between two places (a flight) | 400 to 750ms | `travel` (0.45, 0, 0.1, 1) | A departure, clear travel, a soft arrival. |
| Card opening into a screen | About 520ms | `native` (0.3, 0.75, 0.1, 1) | One element growing, never a swap. |
| Drawer or sheet | About 420ms | `sheet` (0.32, 0.72, 0, 1) | |
| Swipe thrown | About 500ms | `throw` (0.25, 1, 0.5, 1) | At the finger's speed. |
| Dismissed off screen | 200 to 250ms | `exit` | Accelerates away. |
| Something arriving from nowhere | 400ms in UI (up to 1s in storytelling) | `arrive` (0.25, 0.8, 0.25, 1) | |

The curves are in `kit/ease.ts` (`EASE`, `easeCss('out')`, `bezier('travel')` for motion you drive by hand) and as CSS variables in `kit/tokens.css` (`--ss-ease-travel`, `--ss-ease-arrive`, `--ss-ease-out`).

- **Choose duration and curve together, by job.** One easing applied everywhere flattens the hierarchy. A number accumulating after a transfer may take longer than the transfer itself.
- **Travel has a departure, clear travel and a soft arrival.** Length alone doesn't make it fluid.
- **Stagger a group in reading order, 40 to 80ms apart** (60 is a good default); 80 to 120ms between tiles of a grid. One object still enters whole.
- **Related responses overlap.** A changed setting leads, its label follows, then its dependents, each starting before the last has finished. The result still follows its cause.
- **A small expressive icon may overshoot** (a heart, a tick) while its card and text settle without bounce. Keep the accent local.
- **Holding a result means stop.** No pulse, no repeated count, no shimmer on something that has finished.
- **Animate transform and opacity where you can.** Width and height are worth animating for small elements when the point is that neighbors move with them (a label, a chip, a row); never for a whole page.

## Text and values that change

- **Every change moves.** Text that turns into a pill, a menu replaced by another in one frame, a number that jumps: a submenu slides, text rolls, a surface morphs.
- **Change only what changed.** In "$0.01 per 1,000" becoming "$0.0098 per 1,000", only the changed digits move; the rest holds still and what follows moves by the measured width (`Roll`). Words move whole; a change never splits a word.
- **Status words roll, never crossfade in place** (Queued, Running, Passed). Two hand-built spans crossfading overlap mid-fade and read as a smudge. When several rows change at once, cascade them about 60ms apart (`Roll delay`): a column rolling in unison reads as flicker.
- **Numbers roll with `Count`:** each changed digit turns from the old figure to the new one, last digit first, rising rolls up and falling rolls down, unchanged digits and punctuation hold still, tabular figures keep columns fixed. Never lerp the number per frame (the digits blur). Give it a stable slot when neighbors must stay still.
- **A right-aligned value changes against its right edge** (`Roll align="end"`); a status icon beside it keeps a fixed slot.
- **A value that depends on another changes a beat later.** A total rolls after the row that feeds it has landed (`Roll delay`, or schedule the `Count` update).
- **Decide a control's footprint before its label transition.** Either the box holds the largest state and nothing around it moves (`States`), or the box eases to each label and its neighbors move with it (`Roll variant="fade"`, `Button`). Never roll words that didn't change.
- **Streamed text keeps its layout.** Every word is laid out in its final place from the start and revealed in order, so nothing reflows as it arrives (`Stream`).
- **Inspect the glyphs, not only the box.** Text can shimmer or step a pixel as a transform finishes. Give a small moving box with text its own layer (`will-change: transform` on that element only, never the whole page) and keep it through the end of the move.
- **A late-loading font is a text shift too.** Re-measure what was measured from text (the kit's `Tabs` does) or wait for `document.fonts.ready` before the first measured animation.

## Buttons and controls

- **A button changes on itself.** "Resolve" becomes "Resolved" in the same `Button`, which crossfades the label and eases its width so the button beside it moves with it. An icon that arrives later (a tick when done) opens its own slot and fades in. Never swap in a second button.
- **Press, then result.** The press responds at once (scale 0.97, a fill step); the state change comes after the press completes. A result that appears before the press reads as nothing having been pressed.
- **States of one action share one slot.** Label, spinner and done-label stacked in one place and crossfaded, the box holding the largest (`States`), or the box easing between them (`Button`). Check the shortest, the longest and the pending state.
- **Pending hands over to done in one mark.** A ring with a turning arc becomes a filled circle with a tick drawing in (`Check pending` then `Check on`). Never a spinner fading out over a check fading in.
- **A spinner is already turning before it is visible** and keeps turning through its fade out. One that starts spinning after it appears reads as a stall.
- **An object keeps its identity when it changes.** A plus becoming a close rotates the same strokes 45°; replacing the icon loses the relationship.
- **A choice that moves is a `Segmented` or `Tabs`**, whose thumb or underline slides from the old choice to the new. The labels only change color.
- **A switch's knob slides; the track takes the accent** over about 200ms.
- **A focus ring fades in without moving the text.** Draw it as an outline or inset shadow, never by changing a border's width.
- **A text field's placeholder leaves the moment the first character lands** and fades back when emptied. The caret is solid while typing and blinks only once it rests.
- **Typed text becomes a chip in place.** The words stay where they were typed and the chip's surface grows around them; its remove x opens beside them.
- **A draft becomes the posted comment in place.** The typing box's edges sit on the comment's column, it holds the finished comment's height from the first keystroke, and on post the box fades and its padding eases away. Posting adds no new line under the name (a time goes on the name's line and fades in).
- **The pointer stays where the press happened** while the result changes size; a control never slides out from under it.
- **Hover is one step of the control's own color.** Fast in, eased out. Native buttons keep the arrow cursor; links and app-like rows can use the pointer.

## Things that appear, move and leave

- **Nothing pops.** Everything has an entrance and stays mounted until its exit has finished. Keep a `show` prop on the element and unmount on `transitionend`, rather than mounting and unmounting it with the state.
- **No holes or blank frames.** What replaces something arrives as it leaves. A row's content fades in as its height finishes opening; on close it dims first, so the space is never seen empty (`Collapse`).
- **A new row carries the rows below it.** Animate the containing track's height so the line below moves with it, or reserve the space. Its neighbors make room continuously; its fade rides with its travel, not before it.
- **On removal, the row leaves before its space closes;** on insertion, the space opens as the row arrives.
- **Cards, toasts, pills and messages arrive whole, from just above** (`Collapse reveal="drop"`), never uncovered by a hard edge. Only rows of text are revealed by clipping.
- **Solid things don't fade through.** Panels, sheets and cards arrive by moving, opaque or nearly; a half-transparent panel is a ghost.
- **Content arrives after its container.** A badge's number appears once its circle is nearly full size; a panel's text after the panel.
- **A popup fits before its first frame.** It is sized and scrolled before it shows, and never corrects its size while opening.
- **An open surface holds its anchor.** A popover, menu, palette or sheet is pinned by the edge it opened from; reserve the height of its longest list so filtering doesn't move it. It scales from the side nearest its trigger (`Popover origin`).
- **Overlays close where they were.** Keep `{ open, at }` as two values, never a nullable position: closing must not move it to a new place mid-fade.
- **A resizing surface moves its size, position and content as one transition,** never stretching its text, and when interrupted it retargets from where it is.
- **Replacing content keeps the container, its alignment and the reading interval;** only the slot that changes moves, masked softly at its own edges.
- **Keep the header, the outer surface and the action buttons steady** while the content inside changes.
- **A moving edge never slices text.** Fade before and after a height moves, or mask locally; don't blur or soften the whole interface.
- **A zone becoming something else takes its new size** (a drop zone becoming an upload card).
- **Switching versions morphs in place** or crossfades with the container's height eased; never a flash or a hard swap.
- **A page change inside one window keeps the chrome** and crossfades only the body (about 200ms, an 8px rise). On desktop, never slide whole pages sideways.
- **Loading becomes content in place.** A skeleton drawn at the content's own geometry (same row heights, same columns, real chrome around it), resolving top to bottom; nothing jumps when the real rows arrive.
- **A dashed edge never changes size.** Draw it at its final size on its own layer and only fade it. Border style doesn't transition: keep the solid hairline and fade a dashed `::before` over it.
- **A card opening into a screen is one element** (`Expand`): the card's clip grows to fill the screen while its content rides with it.

### Objects that travel

- **One object, one trip, ending in its final place.** Open the room first (`Collapse` or `Slot`), measure where it will land, then fly (`Fly`). Never land and then re-lay out around it.
- **A thing that grows as it travels takes the long settle,** 600ms or more on a soft start and long deceleration; a quick ease-in-out lurches.
- **A flight's ends are fixed at take-off.** If the start or end keeps being re-measured during flight, every change restarts the transition and it creeps, then jumps.
- **Measure the element itself, never its padded wrapper.** A wrapper's rect makes the flyer land a few pixels off and snap.
- **The handoff is invisible.** At landing the real element appears and the flyer disappears in the same frame, at the same size, place and look. The flyer changes to its resting look during the last third of the flight, never on the landing frame.
- **Landings are soft:** decelerate over the last third, back to size before arrival, no bounce, no ring pulse.
- **A highlight moving between items uses `Follow`,** which keeps its momentum when the target changes mid-move. A CSS transition restarts from rest on every change and stutters; re-keying an entrance restarts it from the beginning.

## Lists, drag and reorder

- **A pointer drag is one motion.** With a mouse the item follows the pointer the whole way and drops on release.
- **A drag starts where the thing is,** with the grab offset fixed where the hand took hold, and it rides with the pointer exactly on both axes, with no transition. A file dragged in from outside enters already held.
- **Pickup belongs to the press.** The item lifts on pointer-down plus a small movement (or after a long press: press, hold, lift), never before.
- **A carried card is held, not slid:** scale 1.03, the deeper `--ss-shadow-lift`, a degree or two of tilt following the hand's arc. The whole card tilts, words and all; keep its layer (`will-change: transform`) throughout so its text doesn't hop. It settles flat on drop, with no selection outline in the air.
- **The others make room continuously** as the dragged item passes; they never jump into place.
- **Drop targets don't travel.** The slot appears in a cell and jumps to the next; use hysteresis so a drag along a border doesn't flicker between two cells (`cellOf`). It hides over the card's own cell.
- **Moving a card between lists:** the source's gap closes as the card lifts, the destination's opens (dashed) while it travels, and the card drops into the open gap (`Slot`). Columns keep fixed widths (`minmax(0, 1fr)`) so they don't shift.
- **A text selection reads left to right from a word boundary** and stays under the I-beam on every frame.
- **On a phone, a swiped row stays in its list.** The action is the row's own back, the same height and edge to edge, revealed as the row slides off it, not a separate rounded card beside it. A swipe is a flick: a third of the screen in about a quarter second, then thrown over 0.5s at the finger's speed.
- **In-app phone responses are UIKit-quick:** `native` over about 0.5s.

## Scrolling

- **Lists start with whole rows,** not a row cut in half at the edge.
- **Fade only the edge that hides content,** and only once it does: no fade at the top until the list has scrolled, none at the bottom once it reaches the end.
- **Nothing scrolls by itself** without a reason the person can see.

```css
.list { overflow: auto; }
.list[data-scrolled] { mask-image: linear-gradient(transparent, #000 24px); }
.list[data-more] { mask-image: linear-gradient(#000 calc(100% - 24px), transparent); }
.list[data-scrolled][data-more] { mask-image: linear-gradient(transparent, #000 24px, #000 calc(100% - 24px), transparent); }
```

Set `data-scrolled` when `scrollTop > 0` and `data-more` when `scrollTop + clientHeight < scrollHeight` in a scroll listener.

## Several things changing at once

Start with a readable still and a short account of the change: the frame that holds still, the input that starts things, the responses that depend on it, where it ends, and the hold. Pick timing only once those relationships are clear.

- **Offset the dependents' starts while their movements overlap,** so the order reads: the setting, then its label, then the amount, then the method. All at once is noise; strictly one after another is slow.
- **Keep old and new content in tracks** inside a steady frame, rather than replacing the screen.
- **A soft mask where a track enters and leaves,** local to that slot. Settled text sits wholly inside the opaque part, and the control's border stays outside the mask.
- **Each related update can take its own time:** recognition, transfer and the accumulated result. The result still follows its cause.

Example: changing a checkout's market. The header, card and button stay put; the currency rolls, the price follows about 80ms later, then the payment method and the address field, each overlapping the last.

## Reduced motion and accessibility

- **Respect `prefers-reduced-motion`.** The kit's parts land at once under it (in JS, and through `kit/tokens.css` for their CSS). In your own CSS, replace movement with a short opacity fade or an instant change; keep state feedback (a selected row still shows it is selected) and keep any timing the task itself needs.
- **Motion never carries meaning alone.** A status that rolls also reads correctly as a still; a toast also announces itself (`role="status"`).
- **Real elements.** Buttons are `<button>`, switches have `role="switch"` and `aria-checked`, tabs are a `tablist`, segmented controls are a `radiogroup`, and arrow keys move between options. The kit's controls do this; keep it when restyling.
- **Keep `:focus-visible` rings,** and fade them in without moving anything.
- **Nothing flashes more than three times a second,** and nothing important hides behind hover alone.

## Bug checklist: what you see, what you do

| You see | You do |
|---|---|
| A label replaced instantly ("Open preview" to "Back to editor") | Keep the button; let the old words leave as the new arrive (`Button`, `Roll variant="fade"`). |
| The result appears before the press registers | Press feedback first (0.97 scale, a fill step), then change state. |
| A new row shoves the rows below it | Animate the containing track's height so they move with it (`Collapse`), or reserve the space. |
| A list jumps around an inserted or removed row | Open the space as the row enters whole; let it exit before its space closes. |
| A plus becoming a close by swapping icons | Rotate the same strokes. |
| A dismissed message vanishes | Keep it mounted for its exit (about 320ms), then remove it. |
| A highlight restarts when redirected mid-move | Keep it mounted and retarget from where it is (`Follow`), never re-key its entrance. |
| A flyer lands a few pixels off and snaps | Measure the landing element itself, not its padded wrapper. |
| An icon appearing beside a label makes the label jump | Open the icon's width and its gap together while the label travels; close both on removal. |
| A growing label shoves the button beside it at the end | Ease the width so the neighbor is carried continuously (keep both in normal flex flow). |
| A popup's surface and content resize separately | One geometry for both; text never stretches. |
| A dragged item jumps to a new grip point on pickup | Keep the pointer's offset inside the object through travel and release. |
| A spinner starts turning after it appears | Start rotation before it is visible; keep it turning through its fade out. |
| Text shifts a pixel as it settles | Move it by transform inside a stable grid cell, on a layer it keeps; margin travel moves a shared baseline. |
| Letters crossing a hard edge in a label slot | Soften that boundary locally; resting text sits sharp and wholly inside. |
| Rows cut harshly at a scroll edge | Start with whole rows; fade only the edge hiding content, once scrolled. |
| Dependent values all change on the same frame | Offset their starts while the movements overlap. |
| A menu changes height or moves while open | Pin it by the edge it opened from; reserve the height of the longest list. |
| A blank box for a moment before a panel's content appears | The panel opens with its content (put it in before `open`). |
| A dashed border stretching | Draw it at final size on its own layer; only fade it. |
| A number blurring through every value | Roll the changed digits only (`Count`). |
| A status column changing in unison | Cascade the rows about 60ms apart. |
| Something pulsing or bouncing after it has settled | Stop. Holding a result means stillness. |
| A transparent card or panel fading in over content | Move it in opaque; only fade what is light and small. |
| A component works but feels slow | Feedback is instant; shorten the consequence, not the press. |

## How to check your work

- **Look at the frames between, not the end states.** Matching before-and-after screenshots prove nothing. Slow it down (Chrome DevTools, Animations panel at 10%, or `document.getAnimations().forEach(a => a.playbackRate = 0.1)`) and step through the onset, the overlap, any mask, the cleanup and the hold.
- **Watch the unchanged neighbor** through an insertion and a removal: does it glide or jump?
- **Interrupt it.** Click twice quickly, reverse mid-way, change the target mid-flight. It should retarget from where it is, never restart from the beginning or jump to the end.
- **Turn on reduced motion** (DevTools, Rendering, Emulate CSS prefers-reduced-motion) and check that every state still reads.
- **Use the keyboard:** Tab, arrows, Enter, Escape. Focus rings appear, choices move, nothing animates from a stale position.
- **Check text at real size** after each move: no shimmer, no pixel step, no clipped descenders.
- **Check the narrowest width you ship,** and dark mode.
- **Automate the important ones.** Sample a box mid-transition (a width, a `y`, a transform) and assert it is between its start and end values: that proves it eased rather than jumped.

## The kit

React 18+, TypeScript, no animation library. Copy `kit/` into the project (for example `src/kit`) and import from it:

```tsx
import { Button, Count, Collapse, Popover, Menu, Toast } from './kit'
```

`kit/index.ts` imports `kit/tokens.css` once; every part imports its own CSS. All kit CSS sits in `@layer micro-motion`, so any unlayered rule of yours wins without `!important`. With Tailwind v4 (whose utilities are in a layer too), put this first in your main CSS so utilities can restyle kit parts: `@layer micro-motion, theme, base, components, utilities;`.

**Match your design system** by overriding the tokens on `:root` (dark values under `[data-theme="dark"]` or `.dark`): `--ss-accent`, `--ss-surface`, `--ss-raised`, `--ss-text`, `--ss-text-strong`, `--ss-ink-1` to `--ss-ink-5` (quiet fills, lightest to darkest), `--ss-line`, the status colors (`--ss-success`, `-soft`, `-text`, and the same for danger and warning), the shadows (`--ss-shadow-float`, `--ss-shadow-satellite`, `--ss-shadow-lift`), radii (`--ss-radius-sm`, `-md`, `-lg`, `-pill`) and `--ss-row` (a menu row's height). Restyle a part with a plain class on it; change its color with tokens, never by reshaping its geometry.

**Placing overlays.** `Fly`, `Follow`, `Tooltip` and `Expand` sit absolutely inside a positioned container (`position: relative`). Measure elements against that container with `rectIn(container, el)`, which returns `{ x, y, width, height }` in the container's own pixels.

| Part | Use it for | Key props |
|---|---|---|
| `Roll` | Inline text, prices, statuses: only the changed part rolls; what follows moves by its width | `children` (string), `variant` `'roll'` or `'fade'` (labels on controls), `align` `'start'` or `'end'`, `delay` (ms, a dependent value), `stagger` |
| `Count` | A number whose changed digits roll, last digit first | `value`, `format` (n to string, e.g. currency), `duration` (700), `stagger` (45). A unit after the figure gets its own box, `.ss-count__unit`. |
| `Swap` | Any content replaced in place, its box easing to the new size | `id` (key it on what changed), `duration` (450) |
| `States` | A control's states in one slot, the box holding the largest, so nothing around it moves | `value`, `states` (a record of nodes), `align` |
| `Stream` | Text streaming in word by word with no reflow | `text`, `count` (words shown so far), `mark` (highlight changed words) |
| `Collapse` | A height opening or closing so what follows moves with it: rows, panels, inline errors | `open`, `reveal` `'clip'` (rows of text) or `'drop'` (cards, messages, toasts arriving whole), `from` `'below'` (a message landing at the foot of a feed), `solid` (a surface unlike its ground) |
| `Popover` | A floating surface (menu, picker) scaling from its trigger's side, holding position and contents while it fades out | `show`, `origin` (`'top left'`, `'bottom'`, `'right center'`...). Restyle with `--ss-popover-bg` and `--ss-popover-shadow`. Takes clicks only while open. |
| `Menu` | A popover's rows; the row under the pointer highlights at once and eases out | `items`, `onSelect(index)`, `value` (a row held highlighted, from your keyboard handling) |
| `Fly` | An element carried along a soft arc from one place to another (add to cart, assign, move to folder) | `from`, `to` (rects from `rectIn`), `go`, `held` (shown waiting at `from`), `duration` (750). Draw its child at the start size. |
| `Follow` | A ring or highlight springing onto a rect, keeping momentum when retargeted | `to` (rect or null), `stiffness` (0.25). `cellOf(value, size, prev)` gives sticky cells for drags. |
| `Expand` | A card opening into a full screen or panel as one element | `open`, `from` (the card's rect in the parent), `radius`, `duration`, `face` (an app-launch style zoom). Parent: `position: relative`; set `--ss-expand-open-radius` for rounded open corners. |
| `Button` | A push button whose label and icon change on itself | `variant` (`primary`, `secondary`, `tertiary`, `ghost`, `danger`), `size` (`small` 24, `medium` 28, `large` 32), `icon`, `trailingIcon`, plus every `<button>` attribute |
| `Toggle` | A switch | `on`, `onChange(on)`, `aria-label` |
| `Segmented` | A segmented control whose thumb slides | `items`, `value`, `onChange(index)`, `aria-label` |
| `Tabs` | Tabs with an underline that slides and re-measures | `items`, `value`, `onChange(index)` |
| `Badge` | A status pill | `tone` (`neutral`, `accent`, `success`, `danger`, `warning`), `dot`, `icon` |
| `Chip` | A filter chip that opens and closes its own width, so the chips after it slide | `show`, `onRemove`, `gap` (the row's gap), `removeLabel` |
| `Slot` | A gap in a list that opens and closes (moving a card between lists) | `open`, `height`, `gap`, `dashed` |
| `Toast` | A confirmation that rises in and fades out | `show`, `icon`, `action`. Position its container where your app shows toasts. `--ss-toast-rise` sets the rise. |
| `Tooltip` | A small label under or over a control | `show`, `at` (the control's rect), `side`, `gap` |
| `Spinner` | A pending arc in the current color | `size` |
| `Check` | Pending ring to filled tick, one mark | `on`, `pending`, `size` |
| `Meter` | A bar filling to a value; its color eases with it | `value` (0 to 1), `tone` |
| `useReducedMotion()` | Read the preference in your own motion code | Wrap a subtree in `<StillContext.Provider value>` to settle it (screenshots, visual tests). |

### Recipes

**A save button with progress.** One `Button`, its label and icon changing on itself:

```tsx
<Button variant="primary" disabled={saving}
  icon={saving ? <Spinner /> : saved ? <TickIcon /> : undefined}>
  {saving ? 'Saving' : saved ? 'Saved' : 'Save'}
</Button>
```

**A row added to a list.** Each row lives in a `Collapse`; a new row mounts closed and opens on the next frame; a removed row closes, then leaves your data:

```tsx
{rows.map(r => (
  <Collapse key={r.id} open={!r.leaving} reveal="clip"
    onTransitionEnd={(e) => { if (r.leaving && e.propertyName === 'grid-template-rows') drop(r.id) }}>
    <Row {...r} />
  </Collapse>
))}
```

**A menu from a button.** Keep the popover mounted; toggle `show`; keep where it opened separate from whether it is open:

```tsx
<div style={{ position: 'relative' }}>
  <Button onClick={() => setOpen(o => !o)} trailingIcon={<ChevronIcon />}>Sort</Button>
  <Popover show={open} origin="top left" style={{ top: 'calc(100% + 4px)', left: 0, width: 180 }}>
    <Menu items={['Newest', 'Oldest', 'Name']} onSelect={(i) => { setSort(i); setOpen(false) }} />
  </Popover>
</div>
```

**A total that follows its cause.** The edited row changes first; the total rolls a beat later:

```tsx
<Count value={rowAmount} format={usd} />
<Roll delay={250} align="end">{usd(total)}</Roll>
```

**Add to cart.** Measure both ends in the shell, fly, then hand off in one update:

```tsx
const from = rectIn(shell, productThumb), to = rectIn(shell, cartIcon)
// set go: true and hide the source thumb in the same update;
// after `duration` ms, bump the cart count and set go: false in one update
<Fly from={from} to={to} go={go}><img src={thumb} width={from.width} height={from.height} /></Fly>
```

**A toast.** Always mounted, shown for about 2.5s:

```tsx
<div style={{ position: 'fixed', bottom: 24, left: '50%', translate: '-50%' }}>
  <Toast show={copied} icon={<TickIcon />}>Link copied</Toast>
</div>
```

### Without React

The rules apply to any stack; these CSS patterns carry most of them.

```css
/* Press: instant feedback, label never moves */
.btn { transition: transform 180ms cubic-bezier(0.2, 0.8, 0.2, 1), background-color 160ms ease; }
.btn:active { transform: scale(0.97); transition-duration: 80ms, 160ms; }

/* A height that opens with its content (no fixed height needed) */
.collapse { display: grid; grid-template-rows: 0fr; opacity: 0;
  transition: grid-template-rows 0.42s cubic-bezier(0.4, 0, 0.2, 1) 0.05s, opacity 0.42s cubic-bezier(0, 0.8, 0.5, 1); }
.collapse[data-open] { grid-template-rows: 1fr; opacity: 1;
  transition: grid-template-rows 0.46s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.24s ease-out 0.15s; }
.collapse > * { min-height: 0; overflow: clip; }

/* A popover that scales from its trigger and never pops */
.popover { opacity: 0; pointer-events: none; transform: scale(0.96); transform-origin: top left;
  transition: opacity 0.24s ease, transform 0.24s cubic-bezier(0.4, 0, 1, 1); }
.popover[data-show] { opacity: 1; pointer-events: auto; transform: none;
  transition: opacity 0.18s ease, transform 0.24s cubic-bezier(0.22, 1, 0.36, 1); }

/* A switch */
.switch .knob { transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1); }
.switch { transition: background-color 0.2s ease; }
.switch[aria-checked="true"] .knob { transform: translateX(12px); }

/* A toast that rises in */
.toast { opacity: 0; margin-block: 10px -10px; pointer-events: none;
  transition: opacity 0.35s ease, margin 0.6s cubic-bezier(0.22, 1, 0.36, 1); }
.toast[data-show] { opacity: 1; margin-block: 0; pointer-events: auto; }

@media (prefers-reduced-motion: reduce) {
  .btn, .collapse, .popover, .switch, .switch .knob, .toast { transition-duration: 0.01ms !important; }
}
```

Rolling text, rolling digits, flights and `Follow`'s momentum need measuring and timing in script; port them from `kit/` (each part is one short file with its CSS) rather than approximating them.
